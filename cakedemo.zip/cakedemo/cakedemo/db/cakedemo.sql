-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2015 at 08:19 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cakedemo`
--
CREATE DATABASE IF NOT EXISTS `cakedemo` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cakedemo`;

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--

CREATE TABLE IF NOT EXISTS `site_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `is_display` int(1) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `site_settings`
--

INSERT INTO `site_settings` (`id`, `field`, `value`, `is_display`, `is_active`, `created`, `modified`) VALUES
(1, 'site_name', 'cidemo', 1, 1, '2015-03-06 00:00:00', '2015-03-05 21:29:56'),
(2, 'site_url', 'www.cidemo.com', 1, 1, '2015-03-06 00:00:00', '2015-03-05 21:29:56'),
(3, 'email_from_name', 'Admin Email', 1, 1, '2015-03-06 00:00:00', '2015-03-05 21:31:29'),
(4, 'email_from_address', 'xxx@yyy.com', 1, 1, '2015-03-06 00:00:00', '2015-03-05 21:31:29'),
(5, 'site_offline', '0', 1, 1, '2015-05-16 00:00:00', '2015-05-16 06:16:06'),
(6, 'site_offline_message', 'Site under maintenance', 1, 1, '2015-05-16 00:00:00', '2015-05-16 06:16:06');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
